export default window.utilities
