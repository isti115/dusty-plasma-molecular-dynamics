export default window.physics
