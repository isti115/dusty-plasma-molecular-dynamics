# dusty-plasma-molecular-dynamics-ajp-2019

## Build instructions

- Install **NodeJS** and **npm**: ([https://nodejs.org](https://nodejs.org))
- Download the dependencies: `npm install`
- Execute the build command for the current operating system:
    - mac: `npm run electron:build-mac`
    - linux: `npm run electron:build-linux`
    - win: `npm run electron:build-win`
